# version info
module Soracom
  VERSION = '1.0.8'
end
